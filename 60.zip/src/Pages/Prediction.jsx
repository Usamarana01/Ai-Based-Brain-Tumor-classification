import React from "react";
import PredictionForm from "../Components/PredictionForm";

function Prediction() {
  return <PredictionForm />;
}

export default Prediction;
