import React from 'react';

function Profile() {
  return (
    <div>
      <h2>Profile</h2>
      {/* Profile content here */}
    </div>
  );
}

export default Profile;
